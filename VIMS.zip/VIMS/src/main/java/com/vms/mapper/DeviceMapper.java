package com.vms.mapper;

import java.util.List;

import com.vms.model.DeviceTree;

public interface DeviceMapper 
{
	
	List<DeviceTree> queryDeviceTree();

}
