package com.vms.mapper;

import java.util.List;
import java.util.Map;

import com.vms.model.VehiclePosInfo;
import com.vms.model.VehicleWtihDept;

public interface VehicleMapper 
{
    /**
     * 根据cardnumbers资源关联列表
     *
     * @param id
     * @return
     */
    List<VehiclePosInfo> queryVehicleInfoByCardNumberList(Map<String, Object> param);
    
    
    /**
     * 查询部门信息
     *
     * @param status 
     * @param cardNumber 
     * @return
     */
    List<VehicleWtihDept> queryVehicleWtihDeptInfo(Map<String, Object> param);
    
    
    
    /**
     * 根据cardnumbers资源关联列表
     *
     * @param id
     * @return
     */
    List<VehiclePosInfo> queryVehicleHisInfoByCardNumber(Map<String, Object> param);
    

}
