package com.vms.mapper;

import java.util.List;

import com.vms.model.Organization;
import com.vms.model.Page;

/**
  * @ClassName: OrganizationMapper
  * @Description:
  * @author Comsys-Administrator
  * @date 2017年6月10日 下午3:54:52
  *
  */
public interface OrganizationMapper
{
    /**
     * 删除部门
     *
     * @param id
     * @return
     */
    int deleteOrganizationById(Long id);
    
    /**
     * 添加部门
     *
     * @param organization
     * @return
     */
    int insert(Organization organization);
    
    /**
     * 更新部门
     *
     * @param organization
     * @return
     */
    int updateOrganization(Organization organization);
    
    /**
     * 根据id查询部门
     *
     * @param id
     * @return
     */
    Organization findOrganizationById(Long id);
    
    /**
     * 查询部门
     * 
     */
    List<Organization> queryOrgTreeGrid(Organization organization);
    
    /**
     * 根据pid查询子供电单位
     *
     *
     */
    List<Organization> treeOrgChoose(Organization organization);
    
    /**
     * 根据pid查询子供电单位
     *
     *
     */
    List<Organization> treeOrgChooseColl(Organization organization);
    
    /**
     * 查询一级供电单位并且只按照id排序
     * 
     */
    List<Organization> findRootOrgOrderById(Organization organization);
    
    /**
     * 根据pid查询子供电单位并且只按照id排序
     *
     *
     */
    List<Organization> findSubOrgOrderById(Organization organization);
    
    /**
     * 根据id组查询供电单位
     */
    List<Organization> findOrganizationByIds(String ids);
    
    /**
     * 查询供电单位
     */
    List<Organization> findOrganization(Organization organization);
    
    Organization findOrganizationByCode(String code);
    
    List<Organization> findAllOrganizations(Page<Organization> page);
    
}