package com.vms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.constant.CommonConstant;
import com.vms.model.VehiclePosInfo;
import com.vms.model.VehicleWtihDept;
import com.vms.service.VehicleService;

@Controller
@RequestMapping ("/vehicle")
public class VehicleMgrController extends BaseController 
{
    //private static Logger securityLoger = LoggerFactory.getLogger ("securityLoger");
    
    
    @Autowired
    private VehicleService vehicleService;
    
    
    @RequestMapping ("/query")
    @ResponseBody
    public Object query(HttpServletRequest request)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        
        String cardRequest = request.getParameter(CommonConstant.CARD_NUMBERS);
        
        String cardNumbers = "";
        
        String[] reg_cardNumbers = cardRequest.split(",");
        
        if(reg_cardNumbers!= null)
        {
        	for(String item:reg_cardNumbers)
        	{
        		cardNumbers +=  "\'" + item  + "\'"  + ",";
        	}
        	
        	cardNumbers +=  "\'" + ""  + "\'";
        	
        }
        
        List<VehiclePosInfo> vehicleList = vehicleService.QueryVehiclePosInfo(cardNumbers);
        
        System.out.print(vehicleList.toString());
        
        map.put("list", vehicleList);
        return renderSuccess(map); 
        
    }
    
    
    @RequestMapping ("/queryVehicleWtihDept")
    @ResponseBody
    public Object queryVehicleWtihDept(HttpServletRequest request)
    {
        Map<String, List<List<VehicleWtihDept>>> map = new HashMap<String, List<List<VehicleWtihDept>>>();
        
        List<List<VehicleWtihDept>> result = new ArrayList<List<VehicleWtihDept>>();
        
        String status = request.getParameter(CommonConstant.EQUIP_STATUS);
        
        String cardNumbers = request.getParameter(CommonConstant.CARD_NUMBERS);
        
        List<VehicleWtihDept> vehicleList = vehicleService.QueryVehicleWtihDeptInfo(status,cardNumbers);
        
        //转换为2维List
		if (!vehicleList.isEmpty()) 
		{
			String deptName = vehicleList.get(0).getDeptName();

			List<VehicleWtihDept> value = new ArrayList<VehicleWtihDept>();

			for (VehicleWtihDept item : vehicleList) 
			{

				if (item.getDeptName().equals(deptName)) 
				{
					value.add(item);
				}
				else
				{
					result.add(value);
					value = new ArrayList<VehicleWtihDept>();
					deptName = item.getDeptName();
					value.add(item);
				}
			}
			
			result.add(value);

		}
        
        map.put("list", result);
        return renderSuccess(map); 
        
    }
    
    
    @RequestMapping ("/queryVehicleHistory")
    @ResponseBody
    public Object queryVehicleHistory(HttpServletRequest request)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        
        String startTime = request.getParameter(CommonConstant.START_TIME);
        
        String endTime = request.getParameter(CommonConstant.END_TIME);
        
        String cardNumber = request.getParameter(CommonConstant.CARD_NUMBERS);
        
        List<VehiclePosInfo> vehicleHisList = vehicleService.QueryVehicleHisPosInfo(startTime,endTime,cardNumber);
        
        map.put("list", vehicleHisList);
        return renderSuccess(map); 
        
    }
    
    
    public static void main(String[] args)
    {
    	
        String cardNumbers = "";
        
        String[] reg_cardNumbers = "苏A.A201888,苏A.A201889".split(",");
        
        if(reg_cardNumbers!= null)
        {
        	for(String item:reg_cardNumbers)
        	{
        		cardNumbers +=   "\'" + item  + "\'"  + ",";
        	}
        	
        	cardNumbers +=  "\'" + ""  + "\'";
        	
        }
    	System.out.println(cardNumbers);
    }

}
