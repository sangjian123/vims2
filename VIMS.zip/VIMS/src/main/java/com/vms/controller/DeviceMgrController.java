package com.vms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.model.DeviceTree;
import com.vms.service.DeviceService;

@Controller
@RequestMapping("/device")
public class DeviceMgrController extends BaseController 
{
	@Autowired
	private DeviceService deviceService;

	@RequestMapping("/query")
	@ResponseBody
	public Object query(HttpServletRequest request) 
	{
		Map<String, Object> map = new HashMap<String, Object>();

		List<DeviceTree> deviceTree = deviceService.queryDeviceInfo();

		System.out.print(deviceTree.toString());

		map.put("list", deviceTree);
		return renderSuccess(map);

	}

}
