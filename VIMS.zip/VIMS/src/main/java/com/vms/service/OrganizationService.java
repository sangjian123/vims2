package com.vms.service;

import java.util.List;

import com.vms.model.Organization;
import com.vms.model.Page;
import com.vms.model.User;

/**
 * @description：部门管理
 * @author：zhixuan.wang
 * @date：2015/10/1 14:51
 */
public interface OrganizationService
{
    /**
     * 添加部门
     *
     * @param organization
     */
    int addOrganization(Organization organization);
    
    Page<Organization> findAllOrganizations(Page<Organization> page);
    
    /**
     * 根据id查找部门
     *
     * @param id
     * @return
     */
    Organization findOrganizationById(Long id);
    
    /**
     * 根据id查找部门
     *
     * @param id
     * @return
     */
    Organization findOrganizationByCode(String code);
    
    /**
     * 更新部门
     *
     * @param organization
     */
    int updateOrganization(Organization organization);
    
    /**
     * 根据id删除部门
     *
     * @param id
     */
    int deleteOrganizationById(Long id);
    
    /**
     * 查询部门
     *
     *
     */
    List<Organization> queryOrgTreeGrid(Organization organization);
    
    /**
     * 弹框选择部门列表
     *
     *
     */
    List<Organization> treeOrgChoose(User user);
    
    /**
     * 弹框选择部门列表
     *
     *
     */
    List<Organization> treeOrgChooseColl(User user);
    
    /**
     * 弹框选择部门列表(所有单位)
     *
     *
     */
    List<Organization> treeOrgChooseAll(User user);
    
    /**
     * 根据组织标识查询部门
     *
     * @param ids
     * @return
     */
    List<Organization> findOrganizationByIds(String ids);
    
    /**
     * 查询一级部门并且只按照id排序
     * 
     */
    List<Organization> findRootOrgOrderById(Organization organization);
    
    /**
     * 根据pid查询子部门并且只按照id排序
     *
     *
     */
    List<Organization> findSubOrgOrderById(Organization organization);
    
    /**
     * 查询部门
     *
     *
     */
    List<Organization> findOrganization(Organization organization);
    
}
