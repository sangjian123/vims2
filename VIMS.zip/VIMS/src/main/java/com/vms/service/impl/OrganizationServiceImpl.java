package com.vms.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vms.mapper.OrganizationMapper;
import com.vms.model.OrgTree;
import com.vms.model.Organization;
import com.vms.model.Page;
import com.vms.model.User;
import com.vms.service.OrganizationService;
import com.vms.utils.ConfigHolder;
import com.vms.utils.RedisCacheUtil;
import com.vms.utils.UUIDUtils;

@Service
public class OrganizationServiceImpl implements OrganizationService
{
    
    @Autowired
    private OrganizationMapper organizationMapper;
    
    private static final int SYS_EXP = -1;
    
    private RedisCacheUtil redisCacheUtil = new RedisCacheUtil();
    
    private final String ORG_FLAG = ConfigHolder.getCfg("initThread_organization");
    
    @Override
    public List<Organization> queryOrgTreeGrid(Organization organization)
    {
        return organizationMapper.queryOrgTreeGrid(organization);
    }
    
    /**
     * 将 部门/供电单位 转换成树结构
     *
     * @param list
     *            部门/供电单位列表
     * @return 树结构
     */
    private List<OrgTree> generateOrgTee(List<Organization> list)
    {
        List<OrgTree> trees = new ArrayList<OrgTree>();
        
        if(CollectionUtils.isNotEmpty(list))
        {
            OrgTree tree = null;
            for(Organization org : list)
            {
                tree = new OrgTree();
                tree.setId(String.valueOf(org.getId()));
                tree.setPid(org.getPid());
                tree.setText(StringEscapeUtils.unescapeHtml4(org.getName()));
                trees.add(tree);
            }
        }
        return trees;
    }
    
    @Override
    public int addOrganization(Organization organization)
    {
        int rt = 0;
        organization.setId(UUIDUtils.generate19Long());
        
        organization.setCreatedate(new Date());
        
        rt = organizationMapper.insert(organization);
        
        return rt;
    }
    
    @Override
    public Organization findOrganizationById(Long id)
    {
        return organizationMapper.findOrganizationById(id);
    }
    
    @Override
    public int updateOrganization(Organization organization)
    {
        int rt = 0;
        rt = organizationMapper.updateOrganization(organization);
        return rt;
    }
    
    @Override
    public int deleteOrganizationById(Long id)
    {
        int rt = 0;
        
        rt = organizationMapper.deleteOrganizationById(id);
        return rt;
    }
    
    @Override
    public List<Organization> findOrganizationByIds(String ids)
    {
        return organizationMapper.findOrganizationByIds(ids);
    }
    
    @Override
    public List<Organization> findRootOrgOrderById(Organization organization)
    {
        return organizationMapper.findRootOrgOrderById(organization);
    }
    
    @Override
    public List<Organization> findSubOrgOrderById(Organization organization)
    {
        return organizationMapper.findSubOrgOrderById(organization);
    }
    
    @Override
    public List<Organization> treeOrgChoose(User user)
    {
        Organization organization = new Organization();
        organization.setId(user.getBelongDept());
        return organizationMapper.treeOrgChoose(organization);
    }
    
    @Override
    public List<Organization> treeOrgChooseColl(User user)
    {
        Organization organization = new Organization();
        organization.setId(user.getBelongDept());
        return organizationMapper.treeOrgChooseColl(organization);
    }
    
    @Override
    public List<Organization> treeOrgChooseAll(User user)
    {
        Organization organization = new Organization();
        organization.setId(user.getBelongDept());
        return organizationMapper.treeOrgChoose(organization);
    }
    
    @Override
    public List<Organization> findOrganization(Organization organization)
    {
        return organizationMapper.findOrganization(organization);
    }
    
    @Override
    public Organization findOrganizationByCode(String code)
    {
        return organizationMapper.findOrganizationByCode(code);
    }
    
    @Override
    public Page<Organization> findAllOrganizations(Page<Organization> page)
    {
        List<Organization> list = organizationMapper.findAllOrganizations(page);
        page.setResults(list);
        return page;
    }
    
}