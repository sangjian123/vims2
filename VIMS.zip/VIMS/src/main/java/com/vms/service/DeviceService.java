package com.vms.service;

import java.util.List;

import com.vms.model.DeviceTree;

public interface DeviceService 
{

    /**
     * 
     * @return DeviceTree
     */
	List<DeviceTree> queryDeviceInfo();
	
}
