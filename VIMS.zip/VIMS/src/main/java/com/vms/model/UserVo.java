package com.vms.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @description：UserVo
 */
public class UserVo implements Serializable
{
    /**
     *用户类型-管理员
     */
    public static final int USER_TYPE_ADMINISTRATOR = 0;
    
    /**
     *用户类型-用户
     */
    public static final int USER_TYPE_USER = 1;
    
    /**
     * 
     */
    private static final long serialVersionUID = -6777958953004126087L;
    
    private String id;
    
    @Size (min = 5, max = 16, message = "loginname::validate.loginName")
    private String loginname;
    
    @Size (min = 1, max = 32, message = "belongDept::validate.checkName")
    private String nickName;
    
    @Size (min = 6, max = 20, message = "password::validate.size")
    private String password;
    
    @NotNull (message = "sex::validate.NotBlank")
    private Integer sex;
    
    @NotBlank (message = "roles::validate.NotBlank")
    private String roleIds;
    
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createdate;
    
    private Date updatedate;
    
    private String roleName;
    
    private String loginnameOld;
    
    private String phone;
    
    private List<Role> rolesList;
    
    private Date createdateStart;
    
    private Date createdateEnd;
    
    private Long belongDept;
    
    private int status;
    
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getLoginname()
    {
        return loginname;
    }
    
    public void setLoginname(String loginname)
    {
        this.loginname = loginname == null ? null : loginname.trim();
    }
    
    public String getPassword()
    {
        return password;
    }
    
    public void setPassword(String password)
    {
        this.password = password == null ? null : password.trim();
    }
    
    public Integer getSex()
    {
        return sex;
    }
    
    public void setSex(Integer sex)
    {
        this.sex = sex;
    }
    
    public Date getCreatedate()
    {
        if(createdate == null)
        {
            return null;
        }
        return (Date) createdate.clone();
    }
    
    public void setCreatedate(Date createdate)
    {
        if(createdate == null)
        {
            this.createdate = null;
        }
        else
        {
            this.createdate = (Date) createdate.clone();
        }
    }
    
    public String getPhone()
    {
        return phone;
    }
    
    public void setPhone(String phone)
    {
        this.phone = phone == null ? null : phone.trim();
    }
    
    public List<Role> getRolesList()
    {
        return rolesList;
    }
    
    public void setRolesList(List<Role> rolesList)
    {
        this.rolesList = rolesList;
    }
    
    public String getRoleIds()
    {
        return roleIds;
    }
    
    public void setRoleIds(String roleIds)
    {
        this.roleIds = roleIds;
    }
    
    public Date getCreatedateStart()
    {
        if(createdateStart == null)
        {
            return null;
        }
        return (Date) createdateStart.clone();
    }
    
    public void setCreatedateStart(Date createdateStart)
    {
        if(createdateStart == null)
        {
            this.createdateStart = null;
        }
        else
        {
            this.createdateStart = (Date) createdateStart.clone();
        }
    }
    
    public Date getCreatedateEnd()
    {
        if(createdateEnd == null)
        {
            return null;
        }
        return (Date) createdateEnd.clone();
    }
    
    public void setCreatedateEnd(Date createdateEnd)
    {
        if(createdateEnd == null)
        {
            this.createdateEnd = null;
        }
        else
        {
            this.createdateEnd = (Date) createdateEnd.clone();
        }
    }
    
    public String getLoginnameOld()
    {
        return loginnameOld;
    }
    
    public void setLoginnameOld(String loginnameOld)
    {
        this.loginnameOld = loginnameOld;
    }
    
    public String getRoleName()
    {
        return roleName;
    }
    
    public void setRoleName(String roleName)
    {
        this.roleName = roleName;
    }
    
    public String getNickName()
    {
        return nickName;
    }
    
    public void setNickName(String nickName)
    {
        this.nickName = nickName;
    }
    
    public Long getBelongDept()
    {
        return belongDept;
    }
    
    public void setBelongDept(Long belongDept)
    {
        this.belongDept = belongDept;
    }
    
    public int getStatus()
    {
        return status;
    }
    
    public void setStatus(int status)
    {
        this.status = status;
    }
    
    public Date getUpdatedate()
    {
        return updatedate;
    }
    
    public void setUpdatedate(Date updatedate)
    {
        this.updatedate = updatedate;
    }
    
}