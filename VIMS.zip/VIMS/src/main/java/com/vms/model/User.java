package com.vms.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @description：用户
 * @author：zhixuan.wang @date：2015/10/1 14:51
 */
public class User implements Serializable
{
    
    private static final long serialVersionUID = 6700813629656881143L;
    
    private String id;
    
    private String loginname;
    
    private String nickName;
    
    private String password;
    
    private Integer sex;
    
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createdate;
    
    private Date updatedate;
    
    private String phone;
    
    private Long belongDept;
    
    private String pwdFirstUpdate;
    
    private boolean select;
    
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date pwdUpdateTime;
    
    private int status;
    
    private String code;
    
    private String validateCode;
    
    public String getCode()
    {
        return code;
    }
    
    public void setCode(String code)
    {
        this.code = code;
    }
    
    public String getValidateCode()
    {
        return validateCode;
    }
    
    public void setValidateCode(String validateCode)
    {
        this.validateCode = validateCode;
    }
    
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getLoginname()
    {
        return loginname;
    }
    
    public void setLoginname(String loginname)
    {
        this.loginname = loginname == null ? null : loginname.trim();
    }
    
    public String getPassword()
    {
        return password;
    }
    
    public void setPassword(String password)
    {
        this.password = password == null ? null : password.trim();
    }
    
    public Integer getSex()
    {
        return sex;
    }
    
    public void setSex(Integer sex)
    {
        this.sex = sex;
    }
    
    public Date getCreatedate()
    {
        if(createdate == null)
        {
            return null;
        }
        return (Date) createdate.clone();
    }
    
    public void setCreatedate(Date createdate)
    {
        if(createdate == null)
        {
            this.createdate = null;
        }
        else
        {
            this.createdate = (Date) createdate.clone();
        }
    }
    
    public String getPhone()
    {
        return phone;
    }
    
    public void setPhone(String phone)
    {
        this.phone = phone == null ? null : phone.trim();
    }
    
    public String getPwdFirstUpdate()
    {
        return pwdFirstUpdate;
    }
    
    public void setPwdFirstUpdate(String pwdFirstUpdate)
    {
        this.pwdFirstUpdate = pwdFirstUpdate;
    }
    
    public String getNickName()
    {
        return nickName;
    }
    
    public void setNickName(String nickName)
    {
        this.nickName = nickName;
    }
    
    public Long getBelongDept()
    {
        return belongDept;
    }
    
    public void setBelongDept(Long belongDept)
    {
        this.belongDept = belongDept;
    }
    
    public Date getPwdUpdateTime()
    {
        if(pwdUpdateTime == null)
        {
            return null;
        }
        return (Date) pwdUpdateTime.clone();
    }
    
    public void setPwdUpdateTime(Date pwdUpdateTime)
    {
        if(pwdUpdateTime == null)
        {
            this.pwdUpdateTime = null;
        }
        else
        {
            this.pwdUpdateTime = (Date) pwdUpdateTime.clone();
        }
    }
    
    public Date getUpdatedate()
    {
        return updatedate;
    }
    
    public void setUpdatedate(Date updatedate)
    {
        this.updatedate = updatedate;
    }
    
    public int getStatus()
    {
        return status;
    }
    
    public void setStatus(int status)
    {
        this.status = status;
    }
    
    public boolean isSelect()
    {
        return select;
    }
    
    public void setSelect(boolean select)
    {
        this.select = select;
    }
    
    @Override
    public String toString()
    {
        return "User{ id=" + id + ", loginname='" + loginname + "', nickName='" + nickName + ", sex=" + sex + ", createdate="
            + createdate + ", pwdFirstUpdate=" + pwdFirstUpdate + ", pwdUpdateTime=" + pwdUpdateTime + ", phone='" + phone
            + "\'}";
    }
    
}