package com.vms.model;

import java.io.Serializable;

public class VehiclePosInfo implements Serializable
{
    
    private static final long serialVersionUID = 6700813629656881143L;
    
	private String cardnumber;
	
	private double longitude;
	
	private double dimension;
	
	private double prelongitude;
	
	private double predimension;
	
	private String ctime;
	
	private String displayicon;

	public String getDisplayicon() {
		return displayicon;
	}

	public void setDisplayicon(String displayicon) {
		this.displayicon = displayicon;
	}

	public String getCardnumber() {
		return cardnumber;
	}

	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getDimension() {
		return dimension;
	}

	public void setDimension(double dimension) {
		this.dimension = dimension;
	}

	public double getPrelongitude() {
		return prelongitude;
	}

	public void setPrelongitude(double prelongitude) {
		this.prelongitude = prelongitude;
	}

	public double getPredimension() {
		return predimension;
	}

	public void setPredimension(double predimension) {
		this.predimension = predimension;
	}

	public String getCtime() {
		return ctime;
	}

	public void setCtime(String ctime) {
		this.ctime = ctime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "VehiclePosInfo [cardnumber=" + cardnumber + ", longitude="
				+ longitude + ", dimension=" + dimension + ", prelongitude="
				+ prelongitude + ", predimension=" + predimension + ", ctime="
				+ ctime + ", displayicon=" + displayicon + "]";
	}


	
}
