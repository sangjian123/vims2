package com.vms.model;

import java.io.Serializable;

/**
 * Request基类
 * @author wanlilong
 * @date 2018.02.06
 * @version v1.0
 */
public class RequestBase implements Serializable
{
    
    /**
     * 序列化一致性验证
     */
    private static final long serialVersionUID = 1L;
    
}
