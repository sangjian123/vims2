package com.vms.model;

public class DeviceInfo 
{
	
    private Long id;
    
    private Long pid;
    
    private String name;
    
    private Long isLeaf;
    
    private String desc;
    
    private String url;
    
    private String userName;
    
    private String password;

	public Long getId() 
	{
		return id;
	}

	public void setId(Long id) 
	{
		this.id = id;
	}

	public Long getPid() 
	{
		return pid;
	}

	public void setPid(Long pid) 
	{
		this.pid = pid;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public Long getIsLeaf() 
	{
		return isLeaf;
	}

	public void setIsLeaf(Long isLeaf) 
	{
		this.isLeaf = isLeaf;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) 
	{
		this.desc = desc;
	}

	public String getUrl() 
	{
		return url;
	}

	public void setUrl(String url) 
	{
		this.url = url;
	}

	public String getUserName() 
	{
		return userName;
	}

	public void setUserName(String userName) 
	{
		this.userName = userName;
	}

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}

	@Override
	public String toString() 
	{
		return "DeviceInfo [id=" + id + ", pid=" + pid + ", name=" + name
				+ ", isLeaf=" + isLeaf + ", desc=" + desc + ", url=" + url
				+ ", userName=" + userName + ", password=" + password + "]";
	}

}
