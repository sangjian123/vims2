;
(function($, app) {
	"use strict";
	
	app.controller("ManagementSchedueCtrl", function($scope, $http) {
	})
})(jQuery, app)