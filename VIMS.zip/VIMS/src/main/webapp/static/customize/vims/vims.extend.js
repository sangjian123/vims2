(function($,window){
  
	// 扩展数组删除指定元素的方法
	Array.prototype.remove = function(val) {
	  var index = this.indexOf(val);
	  if (index > -1) {
	    this.splice(index, 1);
	  }
	};
	
	// 检索下标
	$.findMenuIndex=function(menus,stateName,compareAttr)
	{
		if(!stateName)return -1;
		var menuTabIndex=-1;
		for(var m in menus) { if(stateName===menus[m][compareAttr]) { menuTabIndex = m;break; } }	
		return Number(menuTabIndex);
	}
	
	//获得开始坐标和终点坐标连线，与y轴正半轴之间的夹角
	$.getAngle=function(pointStart,pointEnd){
        var px=pointStart.lat,py=pointStart.lng,mx=pointEnd.lat,my=pointEnd.lng;
    	var x = Math.abs(px-mx);
        var y = Math.abs(py-my);
        var z = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
        var cos = y/z;
        var radina = Math.acos(cos);//用反三角函数求弧度
        var angle = Math.floor(180/(Math.PI/radina));//将弧度转换成角度
        //鼠标在第四象限
        if(mx>px&&my>py){ angle = 180 - angle; }
        //鼠标在y轴负方向上
        if(mx==px&&my>py){ angle = 180; }
        //鼠标在x轴正方向上
        if(mx>px&&my==py){ angle = 90; }
        //鼠标在第三象限
        if(mx<px&&my>py){ angle = 180+angle; }
        //鼠标在x轴负方向
        if(mx<px&&my==py){ angle = 270; }
        //鼠标在第二象限
        if(mx<px&&my<py){ angle = 360 - angle; }
        return angle;
    }
})(jQuery,window)