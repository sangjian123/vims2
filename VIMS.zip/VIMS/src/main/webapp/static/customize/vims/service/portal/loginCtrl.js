;
(function($, app) {
	"use strict";
	
	app.controller("LoginCtrl", function($scope, $http) {
		$scope.user={};
		// 点击登陆跳转主页
		$scope.login=function(){
			
			$http.post(basePath + "/doLogin", $scope.user || {}).success(function(result) {
        if (result.success) {
          if($scope.user.loginname == 'root')
          {
            window.location.href = basePath + "/support";
            return;
          } 
          window.location.href = basePath + "/home";
        } else {
          $scope.exception.message = result.msg;
          return;
        }
      })

		}
	})
})(jQuery, app)