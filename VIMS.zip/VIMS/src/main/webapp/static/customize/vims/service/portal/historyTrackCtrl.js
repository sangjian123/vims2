;
(function($, app) {
	"use strict";
	
	app.controller("HistoryTrackCtrl", function($scope, $http,$map,$document,$messager,$timeout) {
		$scope.starttime="2018-05-16 12:10";
		$scope.endtime="2018-05-16 12:20";
		
		// 初始化查询所有部门下设备
		$scope.queryVehiclePosition=function(){
			$http({
	        	method: 'POST',
	        	url: basePath + '/vehicle/queryVehicleWtihDept',
	        	params: {"equip_status":0,"cardnumbers":$scope.cardnumbers}
			})
			.success(function(data) {
				// 2维数组 转换为2级树行结构
				$scope.deptVehicalList=[];
				angular.forEach(data.obj.list,function(n,i){
					var o = {"name":n[0].deptName,list:n};
					$scope.deptVehicalList.push(o);
				})
			});
		}
		$scope.queryVehiclePosition();
		$scope.param={};
		$scope.queryVehicleHistory=function(index,car){
			if(!$scope.starttime || !$scope.endtime)
			{
				$messager.warning("提示","请选择开始和结束时间！");
				return;
			}	
			$scope.param.type=index;//标记选中项
			$http({
            	method: 'POST',
            	url: basePath + '/vehicle/queryVehicleHistory',
            	params: {"starttime":$scope.starttime,"endtime":$scope.endtime,"cardnumbers":car.cardnumber}
			})
			.success(function(data) {
				// 获取点坐标集
				var points = [],target;  
				angular.forEach(data.obj.list,function(v,i){
					target=v;
					points.push(new BMap.Point(v.longitude,v.dimension));
				});
				var viewPort = map.getViewport(points);
				map.clearOverlays();
				map.centerAndZoom(viewPort.center, Math.min(viewPort.zoom,15));
				createBtn(map,points,target);
				// 设置起始点和终点
				createStartEndPoint(map,points);
			});
		}
		var map;
		$map.load().then(function(){
				map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
				map.centerAndZoom(new BMap.Point(116.4035,39.915), 10); 
				map.enableScrollWheelZoom();
				map.addControl(new BMap.NavigationControl());
				map.addControl(new BMap.ScaleControl());
				map.addControl(new BMap.OverviewMapControl());
				map.addControl(new BMap.MapTypeControl());
		});
		
		function createStartEndPoint(map,points){
			if(!points.length)return;
			// 起始点
			var iconImg = new BMap.Icon(basePath + "/static/customize/images/markers.png", new BMap.Size(25, 40),{  
				anchor: new BMap.Size(12, 38),
				imageSize: new BMap.Size(300,300),  
                imageOffset: new BMap.Size(-200, -139)
            });  
	        var marker = new BMap.Marker(points[0], { icon : iconImg });
	        map.addOverlay(marker);
	        // 终点
	        iconImg = new BMap.Icon(basePath + "/static/customize/images/markers.png", new BMap.Size(25, 40),{ 
	        	anchor: new BMap.Size(12, 38),
				imageSize: new BMap.Size(300,300),  
                imageOffset: new BMap.Size(-225, -139)
            });  
	        marker = new BMap.Marker(points[points.length-1], { icon : iconImg });
	        map.addOverlay(marker);
		}
		
		function createBtn(map,points,v){
			if(!v)return;
			var lushu = new BMapLib.LuShu(map,points,{
                defaultContent:v.cardnumber,
                autoView:true,//是否开启自动视野调整，如果开启那么路书在运动过程中会根据视野自动调整
                icon  : new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34)),
                speed: 500,
                enableRotation:true,//是否设置marker随着道路的走向进行旋转
                onclick:function(marker){
                	drawInfoWindow(marker,v)
    			},
    			stopCallback:function(){
    				alert('执行结束后回调...');
    			}
            });
			lushu._addMarker();
			// 定义一个控件类,即function
		    function ZoomControl(){
		      // 默认停靠位置和偏移量
		      this.defaultAnchor = BMAP_ANCHOR_TOP_LEFT;
		      this.defaultOffset = new BMap.Size(60, 15); // 距离左上角位置
		    }

		    // 通过JavaScript的prototype属性继承于BMap.Control
		    ZoomControl.prototype = new BMap.Control();
		    // 自定义控件必须实现自己的initialize方法,并且将控件的DOM元素返回
		    // 在本方法中创建个div元素作为控件的容器,并将其添加到地图容器中
		    ZoomControl.prototype.initialize = function(map){
		      // 创建一个DOM元素
		      var div = document.createElement("div");
		      var span = document.createElement("span");
		      span.className='glyphicon glyphicon-play';
		      // 添加文字说明
		      div.appendChild(span);
		      div.appendChild(document.createTextNode("播放/重播"));
		      // 设置样式
		      div.className="BMapbtn";
		      // 绑定事件,点击一次放大两级
		      div.onclick = function(e){
		    	  lushu.start();//	map.setZoom(map.getZoom() + 2); // 放大2倍
		      }
		      // 添加DOM元素到地图中
		      map.getContainer().appendChild(div);
		      // 将DOM元素返回
		      return div;
		    }
		    // 创建控件
		    var myZoomCtrl = new ZoomControl();
		    // 添加到地图当中
		    map.addControl(myZoomCtrl);
			
			// 行车轨迹线
			var polyline = new BMap.Polyline(points, {strokeColor:"red", strokeWeight:5, strokeOpacity:0.5});  
		    map.addOverlay(polyline); 
		}
		
		function drawInfoWindow(marker,v){
			var html = [
			            	'<div id="infowindow1">',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td style="vertical-align:top;">',
			            						'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            							'<tbody>',
			            								'<tr>',
			            									'<td class="tdinfoaddr" style="padding-bottom:8px"><font color="blue">江苏省苏州市吴江区X306(京杭运河特大桥)(距离苏州市吴江区南星上199米)</font></td>',
			            								'</tr>',
			            							'</tbody>',
			            						'</table>',
			            					'</td>',
			            				'</tr>',
			            			'</tbody>',
			            		'</table>',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td class="tdinfoleft" style="height:2px;" colspan="4"><hr class="horizontal-line" size="1"></td>',
			            				'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft" width="90px">北纬:</td><td class="tdinforight">',marker.point.lat,'</td><td class="tdinfoleft" width="40px">东经:</td><td class="tdinforight">',marker.point.lng,'</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">行驶方向:</td><td class="tdinforight">无</td><td class="tdinfoleft">速度:</td><td class="tdinforight">无</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">点火开关:</td><td class="tdinforight"><font color="red">无</font></td><td class="tdinfoleft">里程:</td><td class="tdinforight">无</td>',
			            			'</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">空调:</td><td class="tdinforight">无</td><td class="tdinfoleft">载客:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">GSM信号:</td><td class="tdinforight">无</td><td class="tdinfoleft">卫星:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">外部电源:</td><td class="tdinforight">无</td><td class="tdinfoleft">震动:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">位置报告时间:</td><td class="tdinforight" colspan="3">',v.currentTime,'</td>',
			            		    '</tr>',
			            		   '</tbody>',
			            		  '</table>',
			            		 '</div>'
			            ].join("");
			var infoWindow = new BMap.InfoWindow(html); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
			$timeout(function(){ $('.BMap_top').html("<label style='margin-top:4px;'>车牌号码："+ v.cardnumber +"</label>") },50);
		}
	})
})(jQuery, app)