package com.icss.ebu.ami.activiti.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.activiti.bean.model.ActHiTaskinst;
import com.icss.ebu.ami.activiti.mapper.ActHiTaskinstMapper;
import com.icss.ebu.ami.activiti.service.ActHiTaskinstService;
import com.icss.ebu.ami.commons.exception.ServiceException;
import com.icss.ebu.ami.commons.pagePlugin.Page;

/**
 * 
 * 
 * @Data 2016-12-13
 * @author liuchang
 * @version v1.0
 */
@Service
@Component ("actHiTaskinstService")
public class ActHiTaskinstServiceImpl implements ActHiTaskinstService
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ActHiTaskinstServiceImpl.class);
    
    @Autowired
    private ActHiTaskinstMapper actHiTaskinstMapper;
    
    public Page<ActHiTaskinst> findgActHiTaskinstByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findgActHiTaskinstByPage(page);
            }
            else
            {
                list = actHiTaskinstMapper.findFileByPage(page);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception",
                e);
        }
        page.setResults(list);
        return page;
    }
    
    public Page<ActHiTaskinst> findWaitHandleByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findWaitHandlesByPage(page);
                if(!CollectionUtils.isEmpty(list))
                {
                    for(ActHiTaskinst act : list)
                    {
                        if(act.getGroupId() != null && "1".equals(act.getRev()))
                        {
                            act.setRev("2");
                        }
                    }
                }
            }
            else
            {
                list = actHiTaskinstMapper.findFileByPage(page);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception",
                e);
        }
        page.setResults(list);
        return page;
    }
    
    public Page<ActHiTaskinst> findGridHandleByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findGridHandleByPage(page);
                if(!CollectionUtils.isEmpty(list))
                {
                    for(ActHiTaskinst act : list)
                    {
                        if(act.getGroupId() != null && "1".equals(act.getRev()))
                        {
                            act.setRev("2");
                        }
                    }
                }
            }
            else
            {
                list = actHiTaskinstMapper.findFileByPage(page);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception",
                e);
        }
        page.setResults(list);
        return page;
    }
    
    public Page<ActHiTaskinst> findgActHiTaskinstTop5ByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findTop5(page);
            }
            else
            {
                list = actHiTaskinstMapper.findTop5File(page);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception",
                e);
        }
        page.setResults(list);
        return page;
    }
    
    @Override
    public Page<ActHiTaskinst> findTaskinstByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstMapper.findTaskinstByPage(page);
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception",
                e);
        }
        page.setResults(list);
        return page;
    }
    
    @Override
    public List<ActHiTaskinst> quaryPnameByPage()
    {
        List<ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstMapper.quaryPnameByPage();
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | quaryPnameByPage Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | quaryPnameByPage SQL Exception", e);
        }
        return list;
    }
    
    @Override
    public List<ActHiTaskinst> quaryName(ActHiTaskinst actHiTaskinst)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstMapper.quaryName(actHiTaskinst);
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | quaryName Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | quaryName SQL Exception", e);
        }
        return list;
    }
    
    @Override
    public Integer findTaskCount(Map<String, Object> map)
    {
        return actHiTaskinstMapper.findTaskCount(map);
    }
    
    @Override
    public Integer findTaskCountAll(Map<String, Object> map)
    {
        return actHiTaskinstMapper.findTaskCountAll(map);
    }
    
    public List<ActHiTaskinst> findgActHiTaskinstForApp(ActHiTaskinst actHiTaskinst)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(actHiTaskinst.getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findgActHiTaskinstForApp(actHiTaskinst);
            }
            else
            {
                list = actHiTaskinstMapper.findFileForApp(actHiTaskinst);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstForApp Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstForApp SQL Exception",
                e);
        }
        return list;
    }
    
}
