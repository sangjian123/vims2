package com.icss.ebu.ami.activiti.mapper;

import java.util.Map;

public interface RecordServerStatusMapper
{
    void recordServerStatus (Map <String, Object> map);
}
