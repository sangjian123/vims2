package com.icss.ebu.ami.activiti.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path ("visit")
@Consumes ({MediaType.APPLICATION_JSON })
@Produces ({MediaType.APPLICATION_JSON })
public interface MonitorApplicationService
{
    
    @GET
    @Path ("index")
    @Consumes ({MediaType.APPLICATION_JSON })
    String visit ();
}
