package com.icss.ebu.ami.activiti.service;

import java.util.Map;

public interface RecordServerStatusService
{
    
    void recordServerStatus (Map <String, Object> map);
    
}
