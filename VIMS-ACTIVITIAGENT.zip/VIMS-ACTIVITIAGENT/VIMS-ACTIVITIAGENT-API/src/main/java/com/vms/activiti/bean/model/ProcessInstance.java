package com.icss.ebu.ami.activiti.bean.model;

import java.io.Serializable;

/**
 * 流程实例维护
 * 
 * @author lucheng
 *
 */
public class ProcessInstance implements Serializable
{
    
    /**
     * 序列化
     */
    private static final long serialVersionUID = -9078178648881539806L;
    
    private String id;
    
    /**
     * The id of the process definition of the process instance.
     */
    private String processDefinitionId;
    
    /**
     * The name of the process definition of the process instance.
     */
    private String processDefinitionName;
    
    /**
     * The key of the process definition of the process instance.
     */
    private String processDefinitionKey;
    
    /**
     * The version of the process definition of the process instance.
     */
    private Integer processDefinitionVersion;
    
    /**
     * The deployment id of the process definition of the process instance.
     */
    private String deploymentId;
    
    /**
     * The business key of this process instance.
     */
    private String businessKey;
    
    /**
     * The tenant identifier of this process instance
     */
    private String tenantId;
    
    /**
     * Returns the name of this process instance.
     */
    private String name;
    
    private String appNo;
    
    private String createTime;
    
    private String processInstanceId;
    
    private String activityId;
    
    private String activityName;
    
    private String assignee;
    
    private String suspendedState;
    
    private boolean suspended;
    
    public String getProcessDefinitionId ()
    {
        return processDefinitionId;
    }
    
    public void setProcessDefinitionId (String processDefinitionId)
    {
        this.processDefinitionId = processDefinitionId;
    }
    
    public String getProcessDefinitionName ()
    {
        return processDefinitionName;
    }
    
    public void setProcessDefinitionName (String processDefinitionName)
    {
        this.processDefinitionName = processDefinitionName;
    }
    
    public String getProcessDefinitionKey ()
    {
        return processDefinitionKey;
    }
    
    public void setProcessDefinitionKey (String processDefinitionKey)
    {
        this.processDefinitionKey = processDefinitionKey;
    }
    
    public Integer getProcessDefinitionVersion ()
    {
        return processDefinitionVersion;
    }
    
    public void setProcessDefinitionVersion (Integer processDefinitionVersion)
    {
        this.processDefinitionVersion = processDefinitionVersion;
    }
    
    public String getDeploymentId ()
    {
        return deploymentId;
    }
    
    public void setDeploymentId (String deploymentId)
    {
        this.deploymentId = deploymentId;
    }
    
    public String getBusinessKey ()
    {
        return businessKey;
    }
    
    public void setBusinessKey (String businessKey)
    {
        this.businessKey = businessKey;
    }
    
    public String getTenantId ()
    {
        return tenantId;
    }
    
    public void setTenantId (String tenantId)
    {
        this.tenantId = tenantId;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getAppNo ()
    {
        return appNo;
    }
    
    public void setAppNo (String appNo)
    {
        this.appNo = appNo;
    }
    
    public String getCreateTime ()
    {
        return createTime;
    }
    
    public void setCreateTime (String createTime)
    {
        this.createTime = createTime;
    }
    
    public String getProcessInstanceId ()
    {
        return processInstanceId;
    }
    
    public void setProcessInstanceId (String processInstanceId)
    {
        this.processInstanceId = processInstanceId;
    }
    
    public String getActivityId ()
    {
        return activityId;
    }
    
    public void setActivityId (String activityId)
    {
        this.activityId = activityId;
    }
    
    public String getActivityName ()
    {
        return activityName;
    }
    
    public void setActivityName (String activityName)
    {
        this.activityName = activityName;
    }
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getAssignee ()
    {
        return assignee;
    }
    
    public void setAssignee (String assignee)
    {
        this.assignee = assignee;
    }
    
    public String getSuspendedState ()
    {
        return suspendedState;
    }
    
    public void setSuspendedState (String suspendedState)
    {
        this.suspendedState = suspendedState;
    }
    
    public boolean isSuspended ()
    {
        return suspended;
    }
    
    public void setSuspended (boolean suspended)
    {
        this.suspended = suspended;
    }
    
}
