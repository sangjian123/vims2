package com.icss.ebu.ami.activiti.bean.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icss.ebu.ami.commons.util.I18nUtils;

/**
 * @description：资源
 * @author：zhixuan.wang
 * @date：2015/10/1 14:51
 */
public class Resource implements Serializable
{
    
    private static final long serialVersionUID = -5321613594382537470L;
    
    private Long id;
    
    private String name;
    
    private String nameFmt;
    
    private String url;
    
    private String description;
    
    @JsonProperty ("iconCls")
    private String icon;
    
    private Long pid;
    
    private Integer seq;
    
    private Integer status;
    
    private Integer resourcetype;
    
    private Date createdate;
    
    private String userId;
    
    private String resourceId;
    
    private String topResourceId;
    
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    
    public Date getCreateTime()
    {
        return createTime;
    }
    
    public void setCreateTime(Date createTime)
    {
        this.createTime = createTime;
    }
    
    public String getResourceId()
    {
        return resourceId;
    }
    
    public void setResourceId(String resourceId)
    {
        this.resourceId = resourceId;
    }
    
    public String getTopResourceId()
    {
        return topResourceId;
    }
    
    public void setTopResourceId(String topResourceId)
    {
        this.topResourceId = topResourceId;
    }
    
    public Long getId()
    {
        return id;
    }
    
    public void setId(Long id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name == null ? null : name.trim ();
    }
    
    public String getUrl()
    {
        return url;
    }
    
    public void setUrl(String url)
    {
        this.url = url == null ? null : url.trim ();
    }
    
    public String getDescription()
    {
        return description;
    }
    
    public void setDescription(String description)
    {
        this.description = description == null ? null : description.trim ();
    }
    
    public String getIcon()
    {
        return icon;
    }
    
    public void setIcon(String icon)
    {
        this.icon = icon == null ? null : icon.trim ();
    }
    
    public Long getPid()
    {
        return pid;
    }
    
    public void setPid(Long pid)
    {
        this.pid = pid;
    }
    
    public Integer getSeq()
    {
        return seq;
    }
    
    public void setSeq(Integer seq)
    {
        this.seq = seq;
    }
    
    public Integer getStatus()
    {
        return status;
    }
    
    public void setStatus(Integer status)
    {
        this.status = status;
    }
    
    public Integer getResourcetype()
    {
        return resourcetype;
    }
    
    public void setResourcetype(Integer resourcetype)
    {
        this.resourcetype = resourcetype;
    }
    
    public Date getCreatedate()
    {
        if (createdate == null)
        {
            return null;
        }
        return (Date) createdate.clone ();
    }
    
    public void setCreatedate(Date createdate)
    {
        if (createdate == null)
        {
            this.createdate = null;
        }
        else
        {
            this.createdate = (Date) createdate.clone ();
        }
    }
    
    public String getUserId()
    {
        return userId;
    }
    
    public void setUserId(String userId)
    {
        this.userId = userId;
    }
    
    public String getNameFmt()
    {
        nameFmt = I18nUtils.getI18nMsg (getName ());
        return nameFmt;
    }
    
    public void setNameFmt(String nameFmt)
    {
        this.nameFmt = nameFmt;
    }
    
    @Override
    public String toString()
    {
        return "Resource{" + "id=" + id + ", name='" + name + '\'' + ", url='" + url + '\'' + ", description='" + description
            + '\'' + ", icon='" + icon + '\'' + ", pid=" + pid + ", seq=" + seq + ", status=" + status + ", resourcetype="
            + resourcetype + ", createdate=" + createdate + ", userId=" + userId + ", resourceId=" + resourceId
            + ", topResourceId=" + topResourceId + '}';
    }
}