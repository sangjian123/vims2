package com.icss.ebu.ami.activiti.bean.model;

import java.io.Serializable;
import java.util.Map;

/**
 * 
 * 封装工作流对象，用于app端调用服务作为参数类型。
 * dubbo服务不支持 Map传参
 * 
 * @author lc
 *
 */
public class Activiti implements Serializable
{
    
    /**
     * 序列化
     */
    private static final long serialVersionUID = 6792804560355838835L;
    
    private String appId; //申请编号：
    
    private String userId; //申请人
    
    private String taskId; //任务编号
    
    private String tprocinstId;
    
    private String status; //状态位，false：回退
    
    private int startMessage;
    
    private String flowFlag;
    
    private String id;
    
    private String deptId; // 部门标识 
    
    private Map <String, Object> variables;

    public Map<String, Object> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, Object> variables) {
        this.variables = variables;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFlowFlag() {
        return flowFlag;
    }

    public void setFlowFlag(String flowFlag) {
        this.flowFlag = flowFlag;
    }

    public String getAppId ()
    {
        return appId;
    }
    
    public void setAppId (String appId)
    {
        this.appId = appId;
    }
    
    public String getUserId ()
    {
        return userId;
    }
    
    public void setUserId (String userId)
    {
        this.userId = userId;
    }
    
    public String getTaskId ()
    {
        return taskId;
    }
    
    public void setTaskId (String taskId)
    {
        this.taskId = taskId;
    }
    
    public String getTprocinstId ()
    {
        return tprocinstId;
    }
    
    public void setTprocinstId (String tprocinstId)
    {
        this.tprocinstId = tprocinstId;
    }
    
    public String getStatus ()
    {
        return status;
    }
    
    public void setStatus (String status)
    {
        this.status = status;
    }
    
    public int getStartMessage ()
    {
        return startMessage;
    }
    
    public void setStartMessage (int startMessage)
    {
        this.startMessage = startMessage;
    }

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
    
}