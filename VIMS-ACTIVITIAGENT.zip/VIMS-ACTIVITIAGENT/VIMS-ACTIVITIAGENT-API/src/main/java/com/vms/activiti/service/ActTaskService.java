package com.icss.ebu.ami.activiti.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.icss.ebu.ami.activiti.bean.model.ActCheckDesc;
import com.icss.ebu.ami.activiti.bean.model.ActHiTaskinst;
import com.icss.ebu.ami.activiti.bean.model.Activiti;
import org.activiti.engine.runtime.ProcessInstance;

@Path ("/actTaskService")
@Consumes ({MediaType.APPLICATION_JSON })
@Produces ({MediaType.APPLICATION_JSON })
public interface ActTaskService
{
    /**
     * 查询代办列表
     * @param actHiTaskinst
     * @return
     */
    @POST
    @Path ("/queryActTaskList")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public List <ActHiTaskinst> queryActTaskList (ActHiTaskinst actHiTaskinst);
    
    /**
     * 工单查询列表
     * @param actHiTaskinst
     * @return
     */
    @POST
    @Path ("/queryActHiTaskList")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public List <ActHiTaskinst> queryActHiTaskList (ActHiTaskinst actHiTaskinst);
    
    /**
     * 选择人员进行流程跳转
     * @param activiti
     * @return
     */
    @POST
    @Path ("/processJumpWorkflow")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public Activiti processJumpWorkflow (Activiti activiti);
    
    /**
     * 发起流程
     * @param activiti
     * @return
     */
    @POST
    @Path ("/startApplyWorkflow")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    ProcessInstance startApplyWorkflow (Activiti activiti);//ApplicationInfo applicationInfo, Map<String, Object> variables, String flowFlag
    
    @POST
    @Path ("/test")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public String test ();
    
    /**
     * 任务领取
     * @param activiti
     */
    @POST
    @Path ("/claim")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public void claim (Activiti activiti);
    
    /**
     * 任务退领
     * @param activiti
     */
    @POST
    @Path ("/unclaim")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public void unclaim (String taskId);
    
    @POST
    @Path ("/suspendProcessInstanceById")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public void suspendProcessInstanceById (String id);
    
    @POST
    @Path ("/setVariables")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public void setVariables (Activiti act);
    
    @POST
    @Path ("/complete")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    public void complete (Activiti act);
    
    /**
     * 新增环节操作备注
     * 
     * @param ActCheckDesc actCheckDesc
     * @return int
     */
    @POST
    @Path ("/insertActDesc")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    int insertActDesc (ActCheckDesc actCheckDesc);
    
    /**
     * 选择部门进行流程跳转
     * @param request
     * @param response
     * @return
     */
    @POST
    @Path ("/gridJumpflow")
    @Produces ({MediaType.APPLICATION_JSON })
    @Consumes ({MediaType.APPLICATION_JSON })
    Activiti gridJumpflow (Activiti activiti);
}
