package com.icss.ebu.ami.activiti.util;

import com.icss.ebu.ami.commons.util.UUIDUtils;
import org.activiti.engine.impl.cfg.IdGenerator;

public class ActivitiIdGenerator implements IdGenerator{

	@Override
	public String getNextId() {
		return UUIDUtils.generate19Str();
	}
}
